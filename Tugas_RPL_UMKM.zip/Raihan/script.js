const modal = document.getElementById("myModal");
const modalImg = document.getElementById("imgModal");
const captionText = document.getElementById("caption");

function openModal(imgSrc, altText) {
    modal.style.display = "block";
    modalImg.src = imgSrc;
    captionText.innerHTML = altText;
}

function closeModal() {
    modal.style.display = "none";
}

// Menutup modal jika area hitam diklik
window.onclick = function(event) {
    if (event.target == modal) {
        closeModal();
    }
}